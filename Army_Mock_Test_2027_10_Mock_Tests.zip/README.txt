Army Mock Test 2027
- 10 mock tests
- 50 questions per test = 500 questions
- 15 GK + 15 Science + 15 Maths + 5 Reasoning per test
- 60-minute timer
- Result + answer review
- Mobile-friendly
- No login/payment required
Open index.html in a browser. Keep questions.json in the same folder.
